//SERVER ROUTES
export const USER_SERVER = '/api/users';
export const CHAT_SERVER = '/api/chat';

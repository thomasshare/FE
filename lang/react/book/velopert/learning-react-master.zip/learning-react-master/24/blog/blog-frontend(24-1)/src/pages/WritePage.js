import React from 'react';

const WritePage = () => {
  return <div>글쓰기</div>;
};

export default WritePage;

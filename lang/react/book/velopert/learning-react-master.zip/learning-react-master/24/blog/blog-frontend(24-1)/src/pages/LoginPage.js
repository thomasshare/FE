import React from 'react';

const LoginPage = () => {
  return <div>로그인</div>;
};

export default LoginPage;

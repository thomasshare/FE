import React from 'react';
import './Red.css';

const Red = () => {
  return <div className="Red">Red</div>;
};

export default Red;

import React from 'react';
import UsersContainer from '../containers/UsersContainer';

const UsersPage = () => {
  return <UsersContainer />;
};

export default UsersPage;

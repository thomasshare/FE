import React from 'react';

const SplitMe = () => {
  return <div>SplitMe</div>;
};

export default SplitMe;

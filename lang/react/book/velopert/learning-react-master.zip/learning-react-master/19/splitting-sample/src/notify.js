export default function notify() {
  alert('안녕하세요!');
}

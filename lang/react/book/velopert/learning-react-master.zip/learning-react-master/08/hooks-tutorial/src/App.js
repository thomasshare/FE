import React from 'react';
import Average from './Average';

const App = () => {
  return <Average />;
};

export default App;
